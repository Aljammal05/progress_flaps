import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame/extensions.dart';
import 'package:flame/game.dart';
import 'package:flame_forge2d/flame_forge2d.dart';
import 'package:flappy_among_us/main.dart';
import 'package:flappy_among_us/pipe_manager.dart';
import 'package:flappy_among_us/pipes.dart';

class Player extends SpriteComponent with CollisionCallbacks, GestureHitboxes {
  var screenWidth;
  var screenHeight;
  SpriteComponent birdAnimation = SpriteComponent();

  Player(
      {Sprite? sprite, required this.screenHeight, required this.screenWidth})
      : super(sprite: sprite);

  @override
  Future<void> onLoad() async {
    birdAnimation = SpriteComponent()
      ..sprite = sprite
      ..size = Vector2(60, 50)
      ..position = Vector2(-50, -60)
      ..center = Vector2(screenWidth / 2, screenHeight / 2)
      ..angle = 0.45;
  }

  // @override
  // void onMount() {
  //   super.onMount();
  //   final shape = CircleHitbox();
  //   add(shape);
  //   debugMode = true;
  // }
  //
  // @override
  // void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
  //   super.onCollision(intersectionPoints, other);
  //   if (other is PipeManager) {
  //     print("hi");
  //   }
  // }
  //
  // @override
  // void render(Canvas canvas) {
  //   super.render(canvas);
  //   renderDebugMode(canvas);
  // }
  //
  // getPlayer() {
  //   return birdAnimation;
  // }
}
