package com.example.flappy_among_us

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
