import 'dart:math';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame/palette.dart';
import 'package:flame_svg/svg.dart';
import 'package:flame_svg/svg_component.dart';
import 'package:flappy_among_us/pipes.dart';
import 'package:flappy_among_us/player.dart';
import 'package:flutter/material.dart';

class PipeManager extends SvgComponent with CollisionCallbacks, GestureHitboxes{
  late Timer timer;
  Svg svgComponent;
  var screenWidth;
  var screenHeight;
  Random random = Random();
  final _defaultColor = Colors.white;

  PipeManager({required this.svgComponent, required this.screenWidth, required this.screenHeight }) : super(){
    timer = Timer(1.5,onTick: (){_spawnPipes();}, repeat: true);
  }

  void _spawnPipes() {
    var randomY = random.nextDouble() * 4;
    Vector2 scale = Vector2(2.7, randomY);
    Vector2 upperScale = Vector2(2.7, (4 - randomY + 2).abs());
    Vector2 initialSize = Vector2(500, 100);

    Pipes lowerPipe = Pipes(
        svg: svgComponent,
        size: initialSize,
        position: Vector2(screenWidth, screenHeight - (100 * randomY))
    );

    Pipes upperPipe = Pipes(
        svg: svgComponent,
        size: initialSize,
        position: Vector2(screenWidth, 0)
    );


    lowerPipe.scale = scale;
    upperPipe.scale = upperScale;
    add(upperPipe);
    add(lowerPipe);
  }

  @override
  void onMount(){
    super.onMount();
    timer.start();
    final shape = RectangleHitbox();
    add(shape);
    // debugMode = true;
  }

  @override
  void onRemove(){
    super.onRemove();
    timer.stop();
  }

  @override
  void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    super.onCollision(intersectionPoints, other);
    if (other is Player) {
      print("hi");
    }
  }

  @override
  void update (double dt) {
    super.update(dt);
    timer.update(dt);
  }

  @override
  void render(Canvas canvas){
    super.render(canvas);

    renderDebugMode(canvas);
  }

}
