

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

import 'main.dart';

class MyCollidable extends PositionComponent
    with HasGameRef<FlappyAmongUs>, CollisionCallbacks{
  late ShapeHitbox hitbox;
  final _defaultColor = Colors.white;

  MyCollidable(Vector2 position, Vector2 size)
      : super(
    position: position,
    size: size,
  );

  @override
  Future<void> onLoad() async {
    final defaultPaint = Paint()
      ..color = _defaultColor
      ..style = PaintingStyle.stroke;
    hitbox = RectangleHitbox(size: size, position: position );
    hitbox.paint = defaultPaint ;
    add(hitbox);
  }

  @override
  void onCollisionStart(
      Set<Vector2> intersectionPoints,
      PositionComponent other,
      ) {
    super.onCollisionStart(intersectionPoints, other);
    if (other is ScreenHitbox) {
      print("hello");
    }
  }

  @override
  void onCollisionEnd(PositionComponent other) {
    super.onCollisionEnd(other);
    if (!isColliding) {
      print("hi");
    }
  }
}
