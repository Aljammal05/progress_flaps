import 'dart:math';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame/experimental.dart';
import 'package:flame/game.dart';
import 'package:flame/parallax.dart';
import 'package:flame_audio/flame_audio.dart';
import 'package:flappy_among_us/collision_detector.dart';
import 'package:flappy_among_us/pipe_manager.dart';
import 'package:flappy_among_us/pipes.dart';
import 'package:flappy_among_us/player.dart';
import 'package:flutter/material.dart';
import 'package:flame_svg/flame_svg.dart';
import 'package:flame_forge2d/flame_forge2d.dart';

void main() {
  runApp(GameWidget(game: FlappyAmongUs()));
}

class FlappyAmongUs extends FlameGame
    with TapCallbacks, HasTappableComponents, HasCollisionDetection,GestureHitboxes {
  SpriteComponent amongUs = SpriteComponent();
  final double characterSize = 60;
  SpriteComponent birdAnimation = SpriteComponent();
  SpriteAnimationComponent backgroundSpriteSheet = SpriteAnimationComponent();
  double gravity = 0;
  Vector2 velocity = Vector2(0, 0);
  double angularAcc = 0.01;
  Vector2 angularVelocity = Vector2(0, 0);
  bool isPressed = false;
  Random random = Random();
  late TextComponent playerScore;
  int score = 0;

  @override
  Future<void> onLoad() async {
    super.onLoad();
    final screenWidth = size[0];
    final screenHeight = size[1];

    ParallaxComponent background = await ParallaxComponent.load(
        List.generate(2, (index) => ParallaxImageData("background.png")),
        repeat: ImageRepeat.repeat,
        baseVelocity: Vector2(50, 0),
        size: Vector2(screenWidth, screenHeight));
    add(background);

    PipeManager pipeManager = PipeManager(
        svgComponent: await loadSvg("images/yellow_pipe.svg"),
        screenWidth: screenWidth,
        screenHeight: screenHeight);
    add(pipeManager);

    // var spriteSheet = await loadSprite("among us ghost2.0.png");
    // Player bird = Player(Vector2(60, 50), Vector2(-60, -50),
    //     Vector2(screenWidth / 2, screenHeight / 2),
    //     imageAmongUs: await loadSprite("among us ghost2.0.png"),
    //     screenWidth: screenWidth,
    //     screenHeight: screenHeight);
    // birdAnimation = bird.getPlayer();
    // add(birdAnimation);
    birdAnimation = SpriteComponent()
    ..sprite = await loadSprite("among us ghost2.0.png")
    ..size = Vector2(60, 50)
    ..position =Vector2(-60, -50)
    ..center = Vector2(screenWidth / 2, screenHeight / 2);
    add(birdAnimation);
    // Player birdAnimation = Player(
    //     sprite: await loadSprite("among us ghost2.0.png"),
    //     screenWidth: screenWidth,
    //     screenHeight: screenHeight);
    // // birdAnimation = bird.getPlayer();
    // add(birdAnimation);


    FlameAudio.bgm.play("song.mp3");
    playerScore = TextComponent(text: "Score : 0", position: Vector2(10, 30));
    add(playerScore);
  }

  @override
  void onTapDown(TapDownEvent event) => isPressed = true;

  @override
  void onTapUp(TapUpEvent event) => isPressed = false;

  @override
  void onTapCancel(TapCancelEvent event) => isPressed = false;

  @override
  void onLongTapDown(TapDownEvent event) {
    super.onLongTapDown(event);
    isPressed = false;
  }

  @override
  void update(double dt) {
    super.update(dt);

    // Falling
    if (birdAnimation.y < size[1] - birdAnimation.height * 0.75) {
      birdAnimation.y += 5;
    }
    if (birdAnimation.angle < 0.9) {
      angularVelocity.y += angularAcc;
      birdAnimation.angle = angularVelocity.y;
    }
    //Jumping
    if (isPressed && birdAnimation.y > 0 + birdAnimation.height * 0.75) {
      birdAnimation.position += Vector2(0, -15);
      if (birdAnimation.angle > -0.9) {
        angularVelocity.y -= .04;
        birdAnimation.angle = angularVelocity.y;
      }
    }
  }
}
