
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame/palette.dart';
import 'package:flame_svg/svg.dart';
import 'package:flame_svg/svg_component.dart';

class Pipes extends SvgComponent with CollisionCallbacks, HasGameRef{

  Pipes({
    Svg? svg,
    Vector2? position,
    Vector2? size,
}) :super(svg: svg,position: position,size: size);

  
  @override
  void update(double dt){
    super.update(dt);
    this.position += Vector2(-2.5, 0);
  }


  

  

}